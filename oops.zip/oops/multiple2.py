# -*- coding: utf-8 -*-
"""
Created on Fri Dec 27 07:59:50 2019

@author: gsripath
"""

#--------------------------------------------------------------------------------------
#Mutiple Inherience
class Father():
    def gardening(self):
        print("I enjoy gardening")

class Mother():
    def cooking(self):
        print("I love cooking")

#a class inherit from two classes
class Child(Father,Mother):
    def sports(self):
        print("I enjoy sprots")
        
c=Child()
c.gardening()
#I enjoy gardening

c.cooking()
#I love cooking

c.sports()
#I enjoy sprots